﻿using Cekirdekler;
using Cekirdekler.ClArrays;
using Cekirdekler.Hardware;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EpicWarCL
{
    public partial class Form1 : Form
    {
        Button[] but = new Button[100];
        float scale = 1.0f;
        float currentScale = 1.0f;

        bool mouseDown = false;
        float lastMouseX = 0f;
        float lastMouseY = 0f;

        float currentMouseX = 0f;
        float currentMouseY = 0f;

        float deltaMouseX = 0f;
        float deltaMouseY = 0f;
        public class ControlWriter : TextWriter
        {
            private Control textbox;
            public ControlWriter(Control textbox)
            {
                this.textbox = textbox;
            }

            public override void Write(char value)
            {
                textbox.Invoke((MethodInvoker)delegate
                {
                    textbox.Text += value;
                });

            }

            public override void Write(string value)
            {
                textbox.Invoke((MethodInvoker)delegate
                {
                    textbox.Text += value;
                });
            }

            public override Encoding Encoding
            {
                get { return Encoding.ASCII; }
            }
        }

        class ModuleNameId
        {
            public int id { get; set; }
            public string name { get; set; }
        }

        void addModuleItems(ComboBox cb)
        {
            List<ModuleNameId> ds = new List<ModuleNameId>();
            ds.Add(new ModuleNameId() { id = moduleTypePower, name = "Power Source" });
            ds.Add(new ModuleNameId() { id = moduleTypeTurret, name = "Cannon Turret" });
            ds.Add(new ModuleNameId() { id = moduleTypeShield, name = "Shield Generator" });
            ds.Add(new ModuleNameId() { id = moduleTypeEnergy, name = "Energy Capacitor" });
            cb.DataSource =ds;
            cb.DisplayMember = "name";
            cb.ValueMember = "id";
        
        }

        public Form1()
        {
            InitializeComponent();
            this.MouseWheel += Form1_MouseWheel;
            this.MouseDown += Form1_MouseDown;
            this.MouseUp += Form1_MouseUp;
            this.MouseMove += Form1_MouseMove;

            System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
            FileVersionInfo fvi = FileVersionInfo.GetVersionInfo(assembly.Location);
            this.Text = "Epic War CL - v" + fvi.FileVersion;

            pictureBox1.Image = Image.FromFile("ship.png");


            
            module0.DropDownStyle = ComboBoxStyle.DropDownList;
            module1.DropDownStyle = ComboBoxStyle.DropDownList;
            module2.DropDownStyle = ComboBoxStyle.DropDownList;
            module3.DropDownStyle = ComboBoxStyle.DropDownList;
            module4.DropDownStyle = ComboBoxStyle.DropDownList;
            module5.DropDownStyle = ComboBoxStyle.DropDownList;
            module6.DropDownStyle = ComboBoxStyle.DropDownList;
            module7.DropDownStyle = ComboBoxStyle.DropDownList;
            module8.DropDownStyle = ComboBoxStyle.DropDownList;
            module9.DropDownStyle = ComboBoxStyle.DropDownList;
            
            
            addModuleItems(module0);
            addModuleItems(module1);
            addModuleItems(module2);
            addModuleItems(module3);
            addModuleItems(module4);
            addModuleItems(module5);
            addModuleItems(module6);
            addModuleItems(module7);
            addModuleItems(module8);
            addModuleItems(module9);

            moduleId[0] = moduleTypePower;
            moduleId[1] = moduleTypePower;
            moduleId[2] = moduleTypePower;
            moduleId[3] = moduleTypePower;
            moduleId[4] = moduleTypePower;
            moduleId[5] = moduleTypePower;
            moduleId[6] = moduleTypePower;
            moduleId[7] = moduleTypePower;
            moduleId[8] = moduleTypePower;
            moduleId[9] = moduleTypePower;

            this.ResizeBegin += (s, e) => { this.SuspendLayout(); };
            this.ResizeEnd += (s, e) => { this.ResumeLayout(true); };
            this.Move += (s, e) => { this.SuspendLayout(); };

        }



        private void Form1_MouseWheel(object sender, MouseEventArgs e)
        {


            if (e.Delta > 0)
                scale *= 0.95f;
            else
                scale *= 1.05f;
            lastMouseX = e.X;
            lastMouseY = e.Y;

            currentMouseX = e.X;
            currentMouseY = e.Y;
            deltaMouseX = 0f;
            deltaMouseY = 0f;
            mouseMovementX = e.X;
            mouseMovementY = e.Y;
        }

        bool rightClick = false;
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                mouseDown = true;
                lastMouseX = e.X;
                lastMouseY = e.Y;

                currentMouseX = e.X;
                currentMouseY = e.Y;
                mouseMovementX = e.X;
                mouseMovementY = e.Y;
                mouseUp = false;
                mouseDownOld = true;
            }
            else if(e.Button==MouseButtons.Right)
            {
                rightClick = true;
            }
        }

        bool mouseUp = false;
        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                mouseMovementX = e.X;
                mouseMovementY = e.Y;

                mouseDown = false;
                mouseUp = true;
                mouseUpOld = true;
            }
            else if (e.Button == MouseButtons.Right)
            {
                rightClick = false;
            }
        }
        float mouseMovementX { get; set; }
        float mouseMovementY { get; set; }
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {


            if (mouseDown)
            {
                lastMouseX = currentMouseX;
                lastMouseY = currentMouseY;

                currentMouseX = e.X;
                currentMouseY = e.Y;
                deltaMouseX = currentMouseX - lastMouseX;
                deltaMouseY = currentMouseY - lastMouseY;

            }


            mouseMovementX = e.X;
            mouseMovementY = e.Y;
            if(mouseDownOld)
            {
                mouseDownOld = false;
            }
        }

        int selectedDeviceId = 0;

        private void Form1_Shown_1(Object sender, EventArgs e)
        {
            GC.Collect();
            ClDevices dvc = ClPlatforms.all().gpus();

            int n = dvc.Length;

            for (int i = 0; i < n; i++)
            {
                Button b = new Button();
                b.Text = dvc[i].logInfo();
                b.Left = 25;
                b.Top = 100 + 40 * i;
                b.Width = 255;
                but[i] = b;
                GC.Collect();
            }

            for (int i = 0; i < but.Length; i++)
            {
                int iL = i;
                this.Invoke((MethodInvoker)delegate
                {
                    if (but[iL] != null)
                    {
                        this.Controls.Add(but[iL]);

                        but[iL].Click += delegate
                        {
                            selectedDeviceId = iL;
                            for (int j = 0; j < but.Length; j++)
                            {
                                if (but[j] != null)
                                {
                                    int jL = j;
                                    but[jL].Invoke((MethodInvoker)delegate { but[jL].Visible = false; });
                                }
                            }
                            backgroundWorker1.RunWorkerAsync();
                            Console.WriteLine(iL);
                        };
                    }
                });
            }
        }


        int fpsCtr = 0;
        const int localSize = 64; // kernel workgroup size
        int renderWidth = 1280 + 512; // must be multiple of 64
        int renderHeight = 512 + 512;
        Bitmap texture { get; set; }
        Bitmap textureOld { get; set; }
        bool started = false;
        byte[] textureBuf { get; set; }
        byte[] textureBuf2 { get; set; } // for double buffering / pipelining(copy + rotate)
        byte[] textureBufTmp { get; set; } // for post processing

        int nShip = 1024 * (128);// must be power of 2
        const int nShipModules = 10;  // max modules at a time, per ship
        const int nShipProjectiles = 8; // max projectiles at a time, per ship
        const int projectileLife = 32; // simulation steps
        const int projectileExplosionLife = 10; // min exploding projectile simulation steps (+ random in kernel)
        const int shipExplosionLife = 33; // ship explosion simulation steps

        // bitfields
        const int moduleTypePower = 1;
        const int moduleTypeEnergy = 2;
        const int moduleTypeShield = 4;
        const int moduleTypeTurret = 8;

        int[] shipHitPoints { get; set; }
        int[] shipShields { get; set; }
        int[] shipShieldsMax { get; set; }
        int[] shipShieldRecharge { get; set; }


        int[] shipCountReductionStep { get; set; }

        int[] shipCount0Ping { get; set; }
        int[] shipCount0Pong { get; set; }

        int[] shipCount1Ping { get; set; }
        int[] shipCount1Pong { get; set; }

        int[] shipCount2Ping { get; set; }
        int[] shipCount2Pong { get; set; }

        byte[] shipTeam { get; set; } // 0=red team, 1=blue team, 2=green team
        int[] shipShieldDamaged { get; set; } // e>0: damaged
        float[] shipX { get; set; }
        float[] shipTargetX { get; set; }
        float[] shipTargetY { get; set; }
        int[] shipCommand { get; set; }
        float[] shipXOld { get; set; }
        float[] shipXTmp { get; set; }
        float[] shipY { get; set; }
        float[] shipYOld { get; set; }
        float[] shipYTmp { get; set; }



        float[] shipFrontX { get; set; }
        float[] shipFrontY { get; set; }

        float[] shipRotation { get; set; }
        byte[] shipState { get; set; }// 1=forward on, 2=rotate left on, 4=rotate right on, 8=dead
        byte[] shipWeaponCharge { get; set; }

        byte[] shipLaserProjectileState { get; set; }// 1=forward on, 2=explosion on, 4=dead
        byte[] shipLaserProjectileLife { get; set; } // 0 - 100: projectile flight, 101-190: explosion, 191: dead
        float[] shipLaserProjectileX { get; set; }
        float[] shipLaserProjectileY { get; set; }
        float[] shipLaserProjectileRotation { get; set; }


        int[] shipSelected { get; set; }
        int[] randSeed { get; set; }

        int mapWidth = (20480);
        int mapHeight = (20480);
        const int shipSize = 10;
        const int shieldDistance = 15;
        const int projectileSize = 1;
        const int searchBoxSize = /*16*/64; // must be power of 2
        const int projectileSearchBoxSize = /*8*/32;// must be power of 2
        const int maxShipsPerBox = 22;
        const int maxProjectilesPerBox = 28;

        // box[i*11]: counter
        // box[i*11+k]: ship id (k>0)
        int[] shipSearchBox { get; set; }
        int[] projectileSearchBox { get; set; }

        byte[] shipModuleType { get; set; }
        byte[] shipModuleEnergy { get; set; }
        byte[] shipModuleHP { get; set; }
        byte[] shipModuleHPMax { get; set; }
        byte[] shipModuleEnergyMax { get; set; }
        byte[] shipModuleWeight { get; set; }
        byte[] shipModuleState { get; set; }

        ClArray<byte> shipModuleTypeGPU { get; set; }
        ClArray<byte> shipModuleEnergyGPU { get; set; }
        ClArray<byte> shipModuleHPGPU { get; set; }
        ClArray<byte> shipModuleHPMaxGPU { get; set; }
        ClArray<byte> shipModuleEnergyMaxGPU { get; set; }
        ClArray<byte> shipModuleWeightGPU { get; set; }
        ClArray<byte> shipModuleStateGPU { get; set; }
        
            
            
            
            
            

        ClArray<int> shipHitPointsGPU { get; set; }
        ClArray<int> shipShieldsGPU { get; set; }
        ClArray<int> shipShieldRechargeGPU { get; set; }

        ClArray<int> shipShieldsMaxGPU { get; set; }

        ClArray<int> numberOfShipsGPU = new ClArray<int>(4096);
        ClArray<int> shipCountReductionStepGPU { get; set; }
        ClArray<int> shipCount0PingGPU { get; set; }
        ClArray<int> shipCount0PongGPU { get; set; }

        ClArray<int> shipCount1PingGPU { get; set; }
        ClArray<int> shipCount1PongGPU { get; set; }

        ClArray<int> shipCount2PingGPU { get; set; }
        ClArray<int> shipCount2PongGPU { get; set; }

        ClArray<byte> textureBufGPU { get; set; }
        ClArray<byte> textureBuf2GPU { get; set; }
        ClArray<byte> textureBufTmpGPU { get; set; }

        ClArray<int> shipSearchBoxGPU { get; set; }
        ClArray<int> projectileSearchBoxGPU { get; set; }
        ClArray<byte> shipTeamGPU { get; set; }
        ClArray<int> shipShieldDamagedGPU { get; set; }
        ClArray<float> shipXGPU { get; set; }
        ClArray<float> shipTargetXGPU { get; set; }
        ClArray<float> shipTargetYGPU { get; set; } // c# arr <--- c++ arr 
        ClArray<int> shipCommandGPU { get; set; }
        

        ClArray<float> shipXOldGPU { get; set; }
        ClArray<float> shipXTmpGPU { get; set; }
        ClArray<float> shipYGPU { get; set; }
        ClArray<float> shipYOldGPU { get; set; }
        ClArray<float> shipYTmpGPU { get; set; }
        ClArray<float> shipFrontXGPU { get; set; }
        ClArray<float> shipFrontYGPU { get; set; }
        ClArray<float> shipRotationGPU { get; set; }
        ClArray<byte> shipStateGPU { get; set; }
        ClArray<byte> shipWeaponChargeGPU { get; set; }

        ClArray<byte> shipLaserProjectileStateGPU { get; set; }
        ClArray<float> shipLaserProjectileXGPU { get; set; }
        ClArray<float> shipLaserProjectileYGPU { get; set; }
        ClArray<float> shipLaserProjectileRotationGPU { get; set; }

        ClArray<byte> shipLaserProjectileLifeGPU { get; set; }

        ClArray<int> parametersIntGPU = new ClArray<int>(4096);
        ClArray<float> parametersFloatGPU = new ClArray<float>(4096);

        
        ClArray<float> rightClickXYGPU = new ClArray<float>(4096);
        ClArray<int> userCommandGPU = new ClArray<int>(4096);

        ClArray<int> randSeedGPU { get; set; }
        ClArray<int> shipSelectedGPU { get; set; }

        ClNumberCruncher cr { get; set; }
        BitmapData bmpData = null;
        BitmapData bmpDataOld = null;


        object syncObj = new object();
        object syncObj2 = new object();
        object syncObjPipelineStage = new object();
        bool alreadyPainted = false;
        bool alreadyPainted2 = false;
        Stopwatch swSecond = new Stopwatch();
        double fpsVal = 0;
        int frameCtr0 = 0;

        int selectedListViewIndexToModuleBitField(int ind)
        {
            if (ind == 0)
                return 1;
            else if (ind == 1)
                return 2;
            else if (ind == 2)
                return 4;
            else if (ind == 3)
                return 8;
            else
                return 0;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            bool pipelineState = false;
            lock (syncObjPipelineStage)
            {
                pipelineState = texturePipelineState;
            }
            base.OnPaint(e);
            e.Graphics.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceCopy;
            e.Graphics.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighSpeed;
            e.Graphics.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.None;
            e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighSpeed;
            if (pipelineState)
            {
                if (!alreadyPainted)
                {
                    lock (syncObj)
                    {
                        if ((textureOld != null) && (bmpDataOld == null))
                            e.Graphics.DrawImage(textureOld, 0, 20);


                        if (swSecond.ElapsedMilliseconds >= 1000)
                        {
                            fpsVal = 1000.0 * frameCtr0 / (double)swSecond.ElapsedMilliseconds;
                            swSecond.Reset();
                            swSecond.Start();
                            frameCtr0 = 0;
                        }
                        frameCtr0++;

                        alreadyPainted = true;
                        alreadyPainted2 = false;
                    }

                }
            }
            else
            {
                if (!alreadyPainted2)
                {
                    lock (syncObj2)
                    {
                        if ((texture != null) && (bmpData == null))
                            e.Graphics.DrawImage(texture, 0, 20);



                        if (swSecond.ElapsedMilliseconds >= 1000)
                        {
                            fpsVal = 1000.0 * frameCtr0 / (double)swSecond.ElapsedMilliseconds;
                            swSecond.Reset();
                            swSecond.Start();
                            frameCtr0 = 0;
                        }
                        frameCtr0++;
                        alreadyPainted2 = true;
                        alreadyPainted = false;
                    }

                }
            }

        }

        bool texturePipelineState = false;
        string strOld = "";
        string strNew = "";
        bool firstRun = true;
        object syncObjComputing = new object();
        Stopwatch swMouseDown = new Stopwatch();
        bool mouseDownOld = false;
        bool mouseUpOld = false;
        int []moduleId = new int[10];

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            // init arrays
            lock (syncObjComputing)
            {


                shipModuleType        = new byte[nShip*nShipModules];
                shipModuleEnergy      = new byte[nShip*nShipModules];
                shipModuleHP          = new byte[nShip*nShipModules];
                shipModuleHPMax       = new byte[nShip*nShipModules];
                shipModuleEnergyMax   = new byte[nShip*nShipModules];
                shipModuleWeight      = new byte[nShip*nShipModules];
                shipModuleState       = new byte[nShip*nShipModules];

                shipSelected = new int[nShip];

                shipHitPoints = new int[nShip];
                shipShields = new int[nShip];
                shipShieldsMax = new int[nShip];
                shipShieldRecharge = new int[nShip];


                shipCountReductionStep = new int[4096];

                shipCount0Ping = new int[nShip];
                shipCount0Pong = new int[nShip];

                shipCount1Ping = new int[nShip];
                shipCount1Pong = new int[nShip];

                shipCount2Ping = new int[nShip];
                shipCount2Pong = new int[nShip];

                shipTeam = new byte[nShip]; // 0=red team, 1=blue team, 2=green team
                shipShieldDamaged = new int[nShip]; // e>0: damaged
                shipX = new float[nShip];
                shipTargetX = new float[nShip];
                shipTargetY = new float[nShip];
                shipCommand = new int[nShip];
                shipXOld = new float[nShip];
                shipXTmp = new float[nShip];
                shipY = new float[nShip];
                shipYOld = new float[nShip];
                shipYTmp = new float[nShip];



                shipFrontX = new float[nShip];
                shipFrontY = new float[nShip];

                shipRotation = new float[nShip];
                shipState = new byte[nShip]; // 1=forward on, 2=rotate left on, 4=rotate right on, 8=dead
                shipWeaponCharge = new byte[nShip];

                shipLaserProjectileState = new byte[nShip * nShipProjectiles]; // 1=forward on, 2=explosion on, 4=dead
                shipLaserProjectileLife = new byte[nShip * nShipProjectiles]; // 0 - 100: projectile flight, 101-190: explosion, 191: dead
                shipLaserProjectileX = new float[nShip * nShipProjectiles];
                shipLaserProjectileY = new float[nShip * nShipProjectiles];
                shipLaserProjectileRotation = new float[nShip * nShipProjectiles];



                randSeed = new int[nShip * nShipProjectiles * 4];

                shipSearchBox = new int[(mapWidth / searchBoxSize) * (mapHeight / searchBoxSize) * (maxShipsPerBox + 1)];
                projectileSearchBox = new int[(mapWidth / projectileSearchBoxSize) * (mapHeight / projectileSearchBoxSize) * (maxProjectilesPerBox + 1)];
            }


            renderWidth = (int)numericUpDown1.Value;
            renderHeight = (int)numericUpDown2.Value;

            Stopwatch sw0 = new Stopwatch();
            Stopwatch sw01 = new Stopwatch();
            sw0.Start();
            sw01.Start();
            Stopwatch sw = new Stopwatch();
            sw.Start();
            swMouseDown.Start();
            double fpsLimiterSleepMs = 1;
            
            swSecond.Start();

            double countWait = 0.00001;
            
            while (sw.ElapsedMilliseconds < 300000)
            {
                
                lock (limitFpsSyncObj)
                {
                    if (limitFps30)
                    {
                        Stopwatch swW = new Stopwatch();
                        swW.Start();
                        long t1 = swW.Elapsed.Ticks; // 100 ns
                        if(fpsVal>30.5)
                        {
                            countWait += 0.00002 * ((fpsVal - 30.0));
                        }

                        if (fpsVal < 29.5)
                        {
                            countWait -= 0.00015 * ((-fpsVal + 29.5));
                        }
                       
                        while ((swW.Elapsed.Ticks - t1)/(double)Stopwatch.Frequency < countWait)
                        {

                        }
                        
                    }
                }
               
                bool details = false;
                lock (cbSync)
                {
                    details = detailLog;
                }

                //Thread.Sleep(1);
                if (!started)
                {
                    this.Invoke((MethodInvoker)delegate
                    {
                        label37.Invoke((MethodInvoker)delegate {
                            label37.Visible = false;
                        });
                        label37.Invalidate();

                        label2.Invoke((MethodInvoker)delegate
                        {
                            label2.Visible = false;
                        });
                        label2.Invalidate();
                        label3.Invoke((MethodInvoker)delegate
                        {
                            label3.Visible = false;
                        });
                        label3.Invalidate();
                        numericUpDown1.Invoke((MethodInvoker)delegate
                        {
                            numericUpDown1.Visible = false;
                        });
                        numericUpDown2.Invoke((MethodInvoker)delegate
                        {
                            numericUpDown2.Visible = false;
                        });
                        numericUpDown1.Invalidate();
                        numericUpDown2.Invalidate();
                        tabControl1.Invoke((MethodInvoker)delegate
                        {
                            tabControl1.Visible = false;
                        });
                        panel1.Invoke((MethodInvoker)delegate
                        {
                            panel1.Visible = false;
                        });
                        tabControl2.Invoke((MethodInvoker)delegate
                        {
                            tabControl2.Visible = false;
                        });

                        hScrollBar1.Invoke((MethodInvoker)delegate
                        {
                            hScrollBar1.Visible = false;
                        });


                        label35.Invoke((MethodInvoker)delegate
                        {
                            label35.Visible = false;
                        });

                        label36.Invoke((MethodInvoker)delegate
                        {
                            label36.Visible = false;
                        });

                        this.Width = renderWidth + 15;
                        this.Height = renderHeight + 59;
                    });
                    started = true;
                    texture = new Bitmap(renderWidth, renderHeight, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
                    textureOld = new Bitmap(renderWidth, renderHeight, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
                }
                


                int numBytes = renderWidth * renderHeight * 4;

                // init
                if (firstRun)
                {
                    firstRun = false;
                    parametersFloatGPU[0] = 1.0f;
                    parametersFloatGPU[1] = mapWidth / 2;
                    parametersFloatGPU[2] = mapHeight / 2;
                    Console.WriteLine(shipSearchBox.Length.ToString());
                    Console.WriteLine(projectileSearchBox.Length.ToString());
                    ClPlatforms pltTmp = ClPlatforms.all();
                    GC.Collect();
                    ClDevices dvcTmp = pltTmp.gpus();
                    GC.Collect();
                    ClDevices slcTmp = dvcTmp[selectedDeviceId];
                    GC.Collect();
                    Console.WriteLine("Compile...");
                    cr = new ClNumberCruncher(slcTmp,

                        File.ReadAllText("opencl_kernels.cl").

                        Replace("@@mapWidth@@", mapWidth.ToString()).
                        Replace("@@mapHeight@@", mapHeight.ToString()).
                        Replace("@@searchBoxSize@@", searchBoxSize.ToString()).
                        Replace("@@nShipProjectiles@@", nShipProjectiles.ToString()).
                        Replace("@@(maxShipsPerBox+1)@@", (maxShipsPerBox + 1).ToString()).
                        Replace("@@(maxProjectilesPerBox+1)@@", (maxProjectilesPerBox + 1).ToString()).
                        Replace("@@maxShipsPerBox@@", maxShipsPerBox.ToString()).
                        Replace("@@shipSize@@", shipSize.ToString()).
                        Replace("@@((mapHeight/searchBoxSize)*(mapWidth/searchBoxSize))@@", ((mapHeight / searchBoxSize) * (mapWidth / searchBoxSize)).ToString()).
                        Replace("@@nShip@@", nShip.ToString()).
                        Replace("@@nProjectile@@", (nShip * nShipProjectiles).ToString()).
                        Replace("@@nShipBox@@", shipSearchBox.Length.ToString()).
                        Replace("@@nProjectileBox@@", projectileSearchBox.Length.ToString()).
                        Replace("@@projectileSearchBoxSize@@", projectileSearchBoxSize.ToString()).
                        Replace("@@maxProjectilesPerBox@@", maxProjectilesPerBox.ToString()).
                        Replace("@@((mapHeight/projectileSearchBoxSize)*(mapWidth/projectileSearchBoxSize))@@", ((mapHeight / projectileSearchBoxSize) * (mapWidth / projectileSearchBoxSize)).ToString()).
                        Replace("@@projectileLife@@", projectileLife.ToString()).
                        Replace("@@projectileExplosionLife@@", projectileExplosionLife.ToString()).
                        Replace("@@shipExplosionLife@@", shipExplosionLife.ToString()).
                        Replace("@@projectileSize@@", projectileSize.ToString()).
                        Replace("@@renderWidth@@", renderWidth.ToString()).
                        Replace("@@nLocalSize@@", localSize.ToString()).
                        Replace("@@nShipModules@@", nShipModules.ToString()).
                        Replace("@@renderHeight@@", renderHeight.ToString()).

                        Replace("@@moduleTypePower@@",  moduleTypePower.ToString()).
                        Replace("@@moduleTypeEnergy@@", moduleTypeEnergy.ToString()).
                        Replace("@@moduleTypeShield@@", moduleTypeShield.ToString()).
                        Replace("@@moduleTypeTurret@@", moduleTypeTurret.ToString()).

                        Replace("@@shieldDistance@@", shieldDistance.ToString()), true, 1
                        );
                    GC.Collect();
                    Console.WriteLine("Buffer...");

                    shipModuleTypeGPU = shipModuleType;
                    shipModuleEnergyGPU = shipModuleEnergy;
                    shipModuleHPGPU = shipModuleHP;
                    shipModuleHPMaxGPU = shipModuleHPMax;
                    shipModuleEnergyMaxGPU = shipModuleEnergyMax;
                    shipModuleWeightGPU = shipModuleWeight;
                    shipModuleStateGPU = shipModuleState;

                    shipModuleTypeGPU.read = false;
                    shipModuleTypeGPU.write = false;
                    shipModuleEnergyGPU.read = false;
                    shipModuleEnergyGPU.write = false;
                    shipModuleHPGPU.read = false;
                    shipModuleHPGPU.write = false;
                    shipModuleHPMaxGPU.read = false;
                    shipModuleHPMaxGPU.write = false;
                    shipModuleEnergyMaxGPU.read = false;
                    shipModuleEnergyMaxGPU.write = false;
                    shipModuleWeightGPU.read = false;
                    shipModuleWeightGPU.write = false;
                    shipModuleStateGPU.read = false;
                    shipModuleStateGPU.write = false;


                    textureBuf = new byte[numBytes];
                    textureBuf2 = new byte[numBytes];
                    textureBufTmp = new byte[numBytes];
                    textureBufGPU = new ClArray<byte>(numBytes);
                    textureBuf2GPU = new ClArray<byte>(numBytes);
                    textureBufTmpGPU = new ClArray<byte>(numBytes);
                    textureBufGPU.writeOnly = true;
                    textureBuf2GPU.writeOnly = true;
                    textureBufTmpGPU.writeOnly = true;
                    textureBufGPU.writeAll = false;
                    textureBufGPU.write = false;
                    textureBuf2GPU.writeAll = false;
                    textureBuf2GPU.write = false;
                    textureBufTmpGPU.writeAll = false;
                    textureBufTmpGPU.write = false;
                    shipSearchBoxGPU = shipSearchBox;
                    shipSearchBoxGPU.read = false;
                    shipSearchBoxGPU.write = false;
                    shipSearchBoxGPU.partialRead = false;
                    shipSearchBoxGPU.writeAll = false;

                    shipShieldDamagedGPU = shipShieldDamaged;
                    shipShieldDamagedGPU.write = false;
                    shipShieldDamagedGPU.read = false;
                    shipShieldDamagedGPU.partialRead = false;
                    shipShieldDamagedGPU.writeAll = false;
                    projectileSearchBoxGPU = projectileSearchBox;
                    projectileSearchBoxGPU.read = false;
                    projectileSearchBoxGPU.write = false;
                    projectileSearchBoxGPU.partialRead = false;
                    projectileSearchBoxGPU.writeAll = false;

                    parametersFloatGPU.write = false;
                    parametersIntGPU.write = false;
                    rightClickXYGPU.write = false;
                    rightClickXYGPU.read = false;
                    userCommandGPU.write = false;
                    userCommandGPU.read = false;

                    parametersFloatGPU.readOnly = true;
                    parametersIntGPU.readOnly = true;

                    randSeedGPU = randSeed;
                    randSeedGPU.write = false;
                    randSeedGPU.read = false;

                    shipTeamGPU = shipTeam;
                    shipXGPU = shipX;
                    shipTargetXGPU = shipTargetX;
                    shipTargetYGPU = shipTargetY;
                    shipCommandGPU = shipCommand;
                    shipXOldGPU = shipXOld;
                    shipXTmpGPU = shipXTmp;
                    shipFrontXGPU = shipFrontX;
                    shipYGPU = shipY;
                    shipYOldGPU = shipYOld;
                    shipYTmpGPU = shipYTmp;
                    shipFrontYGPU = shipFrontY;
                    shipRotationGPU = shipRotation;
                    shipStateGPU = shipState;
                    shipWeaponChargeGPU = shipWeaponCharge;
                    shipLaserProjectileStateGPU = shipLaserProjectileState;
                    shipLaserProjectileXGPU = shipLaserProjectileX;
                    shipLaserProjectileYGPU = shipLaserProjectileY;
                    shipLaserProjectileRotationGPU = shipLaserProjectileRotation;
                    shipLaserProjectileLifeGPU = shipLaserProjectileLife;

                    shipSelectedGPU = shipSelected;

                    shipHitPointsGPU = shipHitPoints;
                    shipShieldsGPU = shipShields;
                    shipShieldRechargeGPU = shipShieldRecharge;
                    shipShieldsMaxGPU = shipShieldsMax;
                    shipCountReductionStepGPU = shipCountReductionStep;

                    shipCount0PingGPU = shipCount0Ping;
                    shipCount0PongGPU = shipCount0Pong;

                    shipCount1PingGPU = shipCount1Ping;
                    shipCount1PongGPU = shipCount1Pong;

                    shipCount2PingGPU = shipCount2Ping;
                    shipCount2PongGPU = shipCount2Pong;

                    shipSelectedGPU.read = false;
                    shipSelectedGPU.write = false;
                    shipTeamGPU.read = false;
                    shipXGPU.read = false;
                    shipTargetXGPU.read = false;
                    shipTargetYGPU.read = false;
                    shipCommandGPU.read = false;
                    shipXOldGPU.read = false;
                    shipXTmpGPU.read = false;
                    shipFrontXGPU.read = false;
                    shipYGPU.read = false;
                    shipYOldGPU.read = false;
                    shipYTmpGPU.read = false;
                    shipFrontYGPU.read = false;
                    shipRotationGPU.read = false;
                    shipStateGPU.read = false;
                    shipWeaponChargeGPU.read = false;
                    shipLaserProjectileStateGPU.read = false;
                    shipLaserProjectileXGPU.read = false;
                    shipLaserProjectileYGPU.read = false;
                    shipLaserProjectileRotationGPU.read = false;
                    shipLaserProjectileLifeGPU.read = false;

                    shipHitPointsGPU.read = false;
                    shipShieldsGPU.read = false;
                    shipShieldRechargeGPU.read = false;
                    shipShieldsMaxGPU.read = false;
                    numberOfShipsGPU.read = false;
                    shipCountReductionStepGPU.read = false;
                    shipCount0PingGPU.read = false;
                    shipCount0PongGPU.read = false;
                    shipCount1PingGPU.read = false;
                    shipCount1PongGPU.read = false;
                    shipCount2PingGPU.read = false;
                    shipCount2PongGPU.read = false;

                    shipTeamGPU.write = false;
                    shipXGPU.write = false;
                    shipTargetXGPU.write = false;
                    shipTargetYGPU.write = false;
                    shipCommandGPU.write = false;
                    shipXOldGPU.write = false;
                    shipXTmpGPU.write = false;
                    shipFrontXGPU.write = false;
                    shipYGPU.write = false;
                    shipYOldGPU.write = false;
                    shipYTmpGPU.write = false;
                    shipFrontYGPU.write = false;
                    shipRotationGPU.write = false;
                    shipStateGPU.write = false;
                    shipWeaponChargeGPU.write = false;
                    shipLaserProjectileStateGPU.write = false;
                    shipLaserProjectileXGPU.write = false;
                    shipLaserProjectileYGPU.write = false;
                    shipLaserProjectileRotationGPU.write = false;
                    shipLaserProjectileLifeGPU.write = false;

                    shipHitPointsGPU.write = false;
                    shipShieldsGPU.write = false;
                    shipShieldRechargeGPU.write = false;
                    shipShieldsMaxGPU.write = false;
                    numberOfShipsGPU.write = true; // info for winforms label
                    numberOfShipsGPU.writeAll = true;
                    shipCountReductionStepGPU.write = false;
                    shipCount0PingGPU.write = false;
                    shipCount0PongGPU.write = false;
                    shipCount1PingGPU.write = false;
                    shipCount1PongGPU.write = false;
                    shipCount2PingGPU.write = false;
                    shipCount2PongGPU.write = false;



                    parametersIntGPU[1] = moduleId[0];
                    parametersIntGPU[2] = moduleId[1];
                    parametersIntGPU[3] = moduleId[2];
                    parametersIntGPU[4] = moduleId[3];
                    parametersIntGPU[5] = moduleId[4];
                    parametersIntGPU[6] = moduleId[5];
                    parametersIntGPU[7] = moduleId[6];
                    parametersIntGPU[8] = moduleId[7];
                    parametersIntGPU[9] = moduleId[8];
                    parametersIntGPU[10] = moduleId[9];

                    parametersIntGPU[11] = team;

                    if (details)
                        Console.WriteLine("rnd_0");
                    randSeedGPU.compute(cr, 0, "rnd_0", randSeed.Length, localSize);




                    if (details)
                        Console.WriteLine("initShips");
                    shipXGPU.nextParam(shipYGPU, shipStateGPU, shipRotationGPU,
                        shipTeamGPU, randSeedGPU, shipHitPointsGPU, 
                        shipXOldGPU, shipYOldGPU,parametersIntGPU).compute(cr, 1, "initShips", nShip, localSize);

                    if (details)
                        Console.WriteLine("initShipModule");
                    shipModuleTypeGPU.nextParam(shipModuleEnergyGPU, shipModuleHPGPU, shipModuleHPMaxGPU,
                        randSeedGPU, shipModuleEnergyMaxGPU, shipModuleWeightGPU,
                        shipModuleStateGPU, shipShieldsMaxGPU, shipShieldsGPU, shipTeamGPU, parametersIntGPU).compute(cr, 999000, "initShipModule", nShip, localSize);


                    if (details)
                        Console.WriteLine("initShipProjectiles");
                    shipLaserProjectileXGPU.nextParam(shipLaserProjectileYGPU, shipLaserProjectileStateGPU,
                        shipLaserProjectileRotationGPU).compute(cr, 2, "initShipProjectiles", nShip, localSize);

                    textureBufGPU.numberOfElementsPerWorkItem = 4; // 4 char argb
                    textureBuf2GPU.numberOfElementsPerWorkItem = 4; // 4 char argb
                    textureBufTmpGPU.numberOfElementsPerWorkItem = 4;
                }
                // init end

                currentScale += (scale - currentScale) * 0.02f;
                parametersFloatGPU[0] = currentScale;
                float tmpX = deltaMouseX * currentScale;
                float tmpY = deltaMouseY * currentScale;
                parametersFloatGPU[1] -= tmpX; deltaMouseX *= 0.98f;
                parametersFloatGPU[2] -= tmpY; deltaMouseY *= 0.98f;
                parametersFloatGPU[3] = currentMouseX;
                parametersFloatGPU[4] = currentMouseY;
                parametersFloatGPU[5] = mouseMovementX  ;
                parametersFloatGPU[6] = mouseMovementY  ;
                parametersFloatGPU[7] = (rightClick?1.0f:0.0f);
                parametersFloatGPU[8] = currentScale;



                if (mouseDownOld)
                {
                    swMouseDown.Reset();
                    swMouseDown.Start();
                    mouseDownOld = false;
                }
                
                if (mouseUpOld)
                {
                    if (swMouseDown.ElapsedMilliseconds < 150)
                    {

                        parametersIntGPU[0] = 1; // mouse click;
                    }
                    else
                    {
                        parametersIntGPU[0] = 0; // x mouse click;
                    }
                    swMouseDown.Reset();
                    swMouseDown.Start();
                    mouseUpOld = false;
                }
                else
                {
                    parametersIntGPU[0] = 0;// x mouse click;
                }
                
                

                if (((((mapWidth / searchBoxSize) * (mapHeight / searchBoxSize))) % localSize) != 0)
                {
                    Console.WriteLine("resetBoxes local size not multiple of " + localSize);
                    Environment.Exit(0);
                }

                if (((((mapWidth / projectileSearchBoxSize) * (mapHeight / projectileSearchBoxSize))) % localSize) != 0)
                {
                    Console.WriteLine("resetProjectileBoxes local size not multiple of " + localSize);
                    Environment.Exit(0);
                }

                // switch textures for double buffering
                lock (syncObjPipelineStage)
                {
                    texturePipelineState = !texturePipelineState;
                }

                //cr.performanceFeed = true;

                lock (syncObjComputing)
                {

                    if (stopComputing)
                    {
                        stopComputing = false;
                        break;
                    }
                }
                Parallel.For(0, 2, threadId =>
                    {
                        if (threadId == 0)
                        {
                            if (!details)
                                cr.enqueueMode = true;



                            parametersFloatGPU.read = true;
                            parametersIntGPU.read = true;

                            parametersFloatGPU.nextParam(parametersIntGPU).compute(cr, 100000, "loadFloatIntParameters", 1, 1);
                            parametersFloatGPU.read = false;
                            parametersIntGPU.read = false;



                            shipTargetXGPU.nextParam(shipTargetYGPU, shipCommandGPU, rightClickXYGPU,
                                userCommandGPU, shipSelectedGPU, parametersFloatGPU).compute(cr, 200000, "rightClickCompute", nShip, localSize);


                        shipTargetXGPU.nextParam(shipTargetYGPU, shipXGPU, shipYGPU,
                            shipCommandGPU,shipStateGPU,shipRotationGPU).compute(cr, 300000, "rotateShipByCommand", nShip, localSize);




                            if (texturePipelineState)
                            {
                                if (details)
                                    Console.WriteLine("clearTexture");
                                textureBufGPU.writeAll = false;
                                textureBufGPU.write = false;
                                textureBufGPU.compute(cr, 3, "clearTexture", renderWidth * renderHeight, localSize);
                            }
                            else
                            {
                                if (details)
                                    Console.WriteLine("clearTexture");
                                textureBuf2GPU.writeAll = false;
                                textureBuf2GPU.write = false;
                                textureBuf2GPU.compute(cr, 4, "clearTexture", renderWidth * renderHeight, localSize);
                            }

                            if (details)
                                Console.WriteLine("resetShieldAnimation");
                            shipShieldDamagedGPU.compute(cr, 5, "resetShieldAnimation", nShip, localSize);

                            if (details)
                                Console.WriteLine("resetBoxes");
                            shipSearchBoxGPU.compute(cr, 6, "resetBoxes", (mapWidth / searchBoxSize) * (mapHeight / searchBoxSize), localSize);

                            if (details)
                                Console.WriteLine("resetProjectileBoxes");
                            projectileSearchBoxGPU.compute(cr, 7, "resetProjectileBoxes", (mapWidth / projectileSearchBoxSize) * (mapHeight / projectileSearchBoxSize), localSize);

                            
                            if (details)
                                Console.WriteLine("moveShips");
                            shipXGPU.nextParam(shipYGPU, shipRotationGPU, shipStateGPU, shipXOldGPU, shipYOldGPU).compute(cr, 8, "moveShips", nShip, localSize);
                            
                            if (details)
                                Console.WriteLine("moveShipsVerlet");
                            shipXGPU.nextParam(shipYGPU, shipXOldGPU, shipYOldGPU, shipXTmpGPU, shipYTmpGPU).compute(cr, 9, "moveShipsVerlet", nShip, localSize);

                            if (details)
                                Console.WriteLine("moveProjectiles");
                            shipLaserProjectileXGPU.nextParam(shipLaserProjectileYGPU, shipLaserProjectileRotationGPU,
                                shipLaserProjectileStateGPU, shipXGPU,
                                shipYGPU).compute(cr, 10, "moveProjectiles", nShipProjectiles * nShip, localSize);

                            if (details)
                                Console.WriteLine("calculateShipFronts");
                            shipXGPU.nextParam(shipYGPU, shipRotationGPU, shipFrontXGPU, shipFrontYGPU).compute(cr, 11, "calculateShipFronts", nShip, localSize);

                            if (details)
                                Console.WriteLine("incrementProjectileStates");
                            shipLaserProjectileLifeGPU.nextParam(shipLaserProjectileStateGPU, randSeedGPU).compute(cr, 12, "incrementProjectileStates", nShipProjectiles * nShip, localSize);


                            if (details)
                                Console.WriteLine("incrementShipStates");
                            shipShieldsMaxGPU.nextParam(shipShieldsGPU, shipShieldRechargeGPU).compute(cr, 13, "incrementShipStates", nShip, localSize);

                            

                            if (details)
                                Console.WriteLine("incrementShipModuleStates");
                            shipModuleTypeGPU.nextParam(shipModuleEnergyGPU,
                                shipModuleHPGPU, shipModuleHPMaxGPU, randSeedGPU, shipModuleEnergyMaxGPU, shipModuleWeightGPU,
                                shipModuleStateGPU,shipShieldsMaxGPU,shipShieldsGPU).compute(cr, 999001, "incrementShipModuleStates", nShip, localSize);


                            if (details)
                                Console.WriteLine("processShipStates");
                            shipHitPointsGPU.nextParam(shipStateGPU, shipShieldsGPU).compute(cr, 14, "processShipStates", nShip, localSize);

                            if (details)
                                Console.WriteLine("putShipsToBoxes");
                            shipXGPU.nextParam(shipYGPU, shipSearchBoxGPU, shipStateGPU).compute(cr, 15, "putShipsToBoxes", nShip, localSize);

                            if (details)
                                Console.WriteLine("checkShipShipCollision");
                            shipXGPU.nextParam(shipYGPU, shipXTmpGPU, shipYTmpGPU, shipSearchBoxGPU).compute(cr, 16, "checkShipShipCollision", nShip, localSize);

                            if (details)
                                Console.WriteLine("findEnemyShips");
                            shipXGPU.nextParam(shipYGPU, shipSearchBoxGPU, shipFrontXGPU, shipFrontYGPU, shipLaserProjectileXGPU, shipLaserProjectileYGPU,
                                shipStateGPU, shipLaserProjectileStateGPU, shipLaserProjectileRotationGPU, shipWeaponChargeGPU,
                                randSeedGPU, shipTeamGPU, shipLaserProjectileLifeGPU).nextParam(shipModuleTypeGPU,shipModuleEnergyGPU, 
                                shipModuleHPGPU, shipModuleHPMaxGPU,randSeedGPU, shipModuleEnergyMaxGPU, shipModuleWeightGPU,
                                shipModuleStateGPU).compute(cr, 17, "findEnemyShips", nShip, localSize);

                            if (details)
                                Console.WriteLine("checkProjectileShipCollisions");
                            shipLaserProjectileXGPU.nextParam(shipLaserProjectileYGPU, shipXGPU, shipYGPU,
                                shipLaserProjectileStateGPU, shipSearchBoxGPU, shipFrontXGPU, shipFrontYGPU,
                                shipTeamGPU, shipHitPointsGPU, randSeedGPU, shipShieldsGPU, shipLaserProjectileLifeGPU, shipShieldDamagedGPU).compute(cr, 18, "checkProjectileShipCollisions", nShipProjectiles * nShip, localSize);

                            if (details)
                                Console.WriteLine("putProjectilesToBoxes");
                            shipLaserProjectileXGPU.nextParam(shipLaserProjectileYGPU,
                                projectileSearchBoxGPU, shipLaserProjectileStateGPU).compute(cr, 19, "putProjectilesToBoxes", nShipProjectiles * nShip, localSize);
                            if (texturePipelineState)
                            {
                                if (details)
                                    Console.WriteLine("renderProjectilesToTexture");
                                textureBufGPU.nextParam(projectileSearchBoxGPU, shipLaserProjectileXGPU, shipLaserProjectileYGPU,
                                parametersFloatGPU, parametersIntGPU, shipTeamGPU, shipLaserProjectileRotationGPU,
                                shipLaserProjectileStateGPU, shipLaserProjectileLifeGPU).compute(cr, 20, "renderProjectilesToTexture", renderWidth * renderHeight, localSize);

                                if (details)
                                    Console.WriteLine("renderShipsToTexture");
                                textureBufGPU.nextParam(shipSearchBoxGPU, shipXGPU, shipYGPU, parametersFloatGPU,
                                    parametersIntGPU, shipTeamGPU, shipRotationGPU,
                                    shipFrontXGPU, shipFrontYGPU, shipStateGPU, shipHitPointsGPU, shipShieldDamagedGPU, shipSelectedGPU, rightClickXYGPU, userCommandGPU).compute(cr, 21, "renderShipsToTexture", renderWidth * renderHeight, localSize);
                            }
                            else
                            {
                                if (details)
                                    Console.WriteLine("renderProjectilesToTexture");
                                textureBuf2GPU.nextParam(projectileSearchBoxGPU, shipLaserProjectileXGPU, shipLaserProjectileYGPU,
                                parametersFloatGPU, parametersIntGPU, shipTeamGPU, shipLaserProjectileRotationGPU,
                                shipLaserProjectileStateGPU, shipLaserProjectileLifeGPU).compute(cr, 22, "renderProjectilesToTexture", renderWidth * renderHeight, localSize);

                                if (details)
                                    Console.WriteLine("renderShipsToTexture");
                                textureBuf2GPU.nextParam(shipSearchBoxGPU, shipXGPU, shipYGPU, parametersFloatGPU,
                                    parametersIntGPU, shipTeamGPU, shipRotationGPU,
                                    shipFrontXGPU, shipFrontYGPU, shipStateGPU, shipHitPointsGPU, shipShieldDamagedGPU, shipSelectedGPU, rightClickXYGPU, userCommandGPU).compute(cr, 23, "renderShipsToTexture", renderWidth * renderHeight, localSize);
                            }

                            if (details)
                                Console.WriteLine("countStepReset");
                            shipCountReductionStepGPU.compute(cr, 24, "countStepReset", 1, 1);


                            if (details)
                                Console.WriteLine("resetShipCounter");
                            shipCount0PingGPU.nextParam(shipCount1PingGPU, shipCount2PingGPU,
                                shipCount0PongGPU, shipCount1PongGPU, shipCount2PongGPU).compute(cr, 25, "resetShipCounter", nShip, localSize);

                            if (details)
                                Console.WriteLine("countShips");
                            shipTeamGPU.nextParam(shipStateGPU,
                                shipCount0PingGPU, shipCount1PingGPU, shipCount2PingGPU,
                                shipCount0PongGPU, shipCount1PongGPU, shipCount2PongGPU).compute(cr, 26, "countShips", nShip / 2, localSize);

                            int nShipDividedValue = nShip / 4;
                            for (int m = 0; nShipDividedValue >= 1; nShipDividedValue /= 2, m++)
                            {
                                if ((m % 2) == 0)
                                {
                                    if (nShipDividedValue > localSize)
                                    {
                                        if (details)
                                            Console.WriteLine("countShipsPing");
                                        shipCount0PingGPU.nextParam(shipCount1PingGPU, shipCount2PingGPU,
                                            shipCount0PongGPU, shipCount1PongGPU, shipCount2PongGPU, shipCountReductionStepGPU).compute(cr, 27, "countShipsPing", nShipDividedValue, localSize);
                                    }
                                    else
                                    {
                                        if (details)
                                            Console.WriteLine("countShipsPing");
                                        shipCount0PingGPU.nextParam(shipCount1PingGPU, shipCount2PingGPU,
                                            shipCount0PongGPU, shipCount1PongGPU, shipCount2PongGPU, shipCountReductionStepGPU).compute(cr, 28, "countShipsPing", nShipDividedValue, nShipDividedValue);
                                    }

                                    if (details)
                                        Console.WriteLine("countStepIncrement");
                                    shipCountReductionStepGPU.compute(cr, 29, "countStepIncrement", 1, 1);

                                }
                                else
                                {
                                    if (nShipDividedValue > localSize)
                                    {
                                        if (details)
                                            Console.WriteLine("countShipsPong");
                                        shipCount0PingGPU.nextParam(shipCount1PingGPU, shipCount2PingGPU,
                                            shipCount0PongGPU, shipCount1PongGPU, shipCount2PongGPU, shipCountReductionStepGPU).compute(cr, 30, "countShipsPong", nShipDividedValue, localSize);
                                    }
                                    else
                                    {
                                        if (details)
                                            Console.WriteLine("countShipsPong");
                                        shipCount0PingGPU.nextParam(shipCount1PingGPU, shipCount2PingGPU,
                                            shipCount0PongGPU, shipCount1PongGPU, shipCount2PongGPU, shipCountReductionStepGPU).compute(cr, 31, "countShipsPong", nShipDividedValue, nShipDividedValue);
                                    }

                                    if (details)
                                        Console.WriteLine("countStepIncrement");
                                    shipCountReductionStepGPU.compute(cr, 32, "countStepIncrement", 1, 1);
                                }
                            }

                            if (details)
                                Console.WriteLine("copyNumberOfShips");
                            shipCount0PingGPU.nextParam(shipCount1PingGPU, shipCount2PingGPU,
                               shipCount0PongGPU, shipCount1PongGPU, shipCount2PongGPU, numberOfShipsGPU).compute(cr, 33, "copyNumberOfShips", 1, 1);


                            if (texturePipelineState)
                            {
                                if (details)
                                    Console.WriteLine("postProcessSmooth");
                                textureBufGPU.nextParam(textureBufTmpGPU).compute(cr, 34, "postProcessSmooth", renderWidth * renderHeight, localSize);


                                if (details)
                                    Console.WriteLine("postProcessOutput");
                                textureBufGPU.writeAll = true;
                                textureBufGPU.write = true;
                                textureBufGPU.nextParam(textureBufTmpGPU).compute(cr, 35, "postProcessOutput", renderWidth * renderHeight, localSize);
                            }
                            else
                            {
                                if (details)
                                    Console.WriteLine("postProcessSmooth");
                                textureBuf2GPU.nextParam(textureBufTmpGPU).compute(cr, 36, "postProcessSmooth", renderWidth * renderHeight, localSize);

                                if (details)
                                    Console.WriteLine("postProcessOutput");
                                textureBuf2GPU.writeAll = true;
                                textureBuf2GPU.write = true;
                                textureBuf2GPU.nextParam(textureBufTmpGPU).compute(cr, 37, "postProcessOutput", renderWidth * renderHeight, localSize);
                            }


                            if (!details)
                                cr.enqueueMode = false;

                            for(int ft= frameTimeHistory.Length-1; ft>= 1;ft--)
                            {
                                frameTimeHistory[ft] = frameTimeHistory[ft - 1];
                            }
                            frameTimeHistory[0] =(int) sw0.ElapsedMilliseconds;
                            int tft = 0;
                            for(int ft=0;ft<frameTimeHistory.Length;ft++)
                            {
                                tft += frameTimeHistory[ft];
                            }

                            for (int ft = frameTimeHistory2.Length - 1; ft >= 1; ft--)
                            {
                                frameTimeHistory2[ft] = frameTimeHistory2[ft - 1];
                            }
                            frameTimeHistory2[0] = (int)sw01.ElapsedMilliseconds;
                            int tft2 = 0;
                            for (int ft = 0; ft < frameTimeHistory2.Length; ft++)
                            {
                                tft2 += frameTimeHistory2[ft];
                            }

                            var valLocal = 1000.0 * (frameTimeHistory2.Length / (double)tft2);
                            string strLocal = string.Format("SPS: {0:###.0}", /*valLocal*/fpsVal) + Environment.NewLine +
                            "Team-1(red): " + numberOfShipsGPU[0].ToString() + " ships." + Environment.NewLine +
                            "Team-2(green): " + numberOfShipsGPU[1].ToString() + " ships." + Environment.NewLine +
                            "Team-3(blue): " + numberOfShipsGPU[2].ToString() + " ships.";

                            if (texturePipelineState)
                                strNew = new StringBuilder(strLocal).ToString();
                            else
                                strOld = new StringBuilder(strLocal).ToString();

                            sw01.Stop();
                            sw01.Reset();
                            sw01.Start();

                            
                           
                            sw0.Stop();

                            sw0.Reset();
                            sw0.Start();


                        }
                        else if (threadId == 1)
                        {


                            if (texturePipelineState)
                            {
                                lock (syncObj2)
                                {
                                    bmpData = texture.LockBits(new Rectangle(0, 0, texture.Width, texture.Height), ImageLockMode.WriteOnly, texture.PixelFormat);

                                    IntPtr ptr = bmpData.Scan0;
                                    if (texturePipelineState)
                                    {
                                        textureBuf2GPU.CopyTo(textureBuf2, 0);
                                        Marshal.Copy(textureBuf2, 0, ptr, numBytes);
                                    }
                                    else
                                    {
                                        textureBufGPU.CopyTo(textureBuf, 0);
                                        Marshal.Copy(textureBuf, 0, ptr, numBytes);
                                    }
                                    if (bmpData != null)
                                        texture.UnlockBits(bmpData);


                                    bmpData = null;
                                }
                                
                            }
                            else
                            {
                                lock (syncObj)
                                {
                                    bmpDataOld = textureOld.LockBits(new Rectangle(0, 0, textureOld.Width, textureOld.Height), ImageLockMode.WriteOnly, texture.PixelFormat);

                                    IntPtr ptr = bmpDataOld.Scan0;
                                    if (texturePipelineState)
                                    {
                                        textureBuf2GPU.CopyTo(textureBuf2, 0);
                                        Marshal.Copy(textureBuf2, 0, ptr, numBytes);
                                    }
                                    else
                                    {
                                        textureBufGPU.CopyTo(textureBuf, 0);
                                        Marshal.Copy(textureBuf, 0, ptr, numBytes);
                                    }
                                    if (bmpDataOld != null)
                                        textureOld.UnlockBits(bmpDataOld);



                                    bmpDataOld = null;
                                }
                               
                            }

                            string strLocal = texturePipelineState ? new StringBuilder(strOld).ToString() : new StringBuilder(strNew).ToString();

                            label1.Invoke((MethodInvoker)delegate
                            {
                                label1.Text = strLocal;
                                //label1.Invalidate();
                                //label1.Update();
                            });

                            this.Invalidate();
                            //Application.DoEvents();
                        }
                    });

            }

        }

        double lastFrameTime = 0;
        double lastFrameTime2 = 0;
        double lastFrameTime3 = 0;
        int[] frameTimeHistory = new int[10];
        int[] frameTimeHistory2= new int[10];


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void emailHuseyintugrulbuyukisikgmailcomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Emailing service not implemented.");
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }



        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        bool stopComputing = false;
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            Application.DoEvents();
            lock (syncObjComputing)
            {
                if (cr == null)
                    return;
                stopComputing = true;
            }

            bool notFinished = true;
            while (notFinished)
            {
                Thread.Sleep(25);
                Application.DoEvents();

                lock (syncObjComputing)
                {
                    notFinished = stopComputing;
                }
            }
            Thread.Sleep(500);
        }

        private void allShipsStartWith1d8ShieldPointsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        object cbSync = new object();
        bool detailLog = false;
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            lock (cbSync)
            {
                detailLog = checkBox1.Checked;
            }
        }

        int oldNShip = 0;
        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            lock (syncObjComputing)
            {
                int n = hScrollBar1.Value;
                int n0 = 1;
                for (int i = 0; i < n; i++)
                {
                    n0 *= 2;
                }
                label36.Text = n0.ToString();
                nShip = n0;
                int sqrt = (int)Math.Sqrt(n0);
                int dim = sqrt * 55;
                dim += (512 - dim % 512);
                mapWidth = (dim);
                mapHeight = (dim);
                Console.WriteLine(dim);
            }
        }

        private void label36_Click(object sender, EventArgs e)
        {

        }

        private void label35_Click(object sender, EventArgs e)
        {

        }
        bool limitFps30 = false;
        object limitFpsSyncObj = new object();
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            lock (limitFpsSyncObj)
            {
                limitFps30 = checkBox2.Checked;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            moduleId[0] = ((ModuleNameId)((ComboBox)sender).SelectedItem).id;
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            moduleId[1] = ((ModuleNameId)((ComboBox)sender).SelectedItem).id;
        }

        private void module2_SelectedIndexChanged(object sender, EventArgs e)
        {
            moduleId[2] = ((ModuleNameId)((ComboBox)sender).SelectedItem).id;
        }

        private void module3_SelectedIndexChanged(object sender, EventArgs e)
        {
            moduleId[3] = ((ModuleNameId)((ComboBox)sender).SelectedItem).id;
        }

        private void module4_SelectedIndexChanged(object sender, EventArgs e)
        {
            moduleId[4] = ((ModuleNameId)((ComboBox)sender).SelectedItem).id;
        }

        private void module5_SelectedIndexChanged(object sender, EventArgs e)
        {
            moduleId[5] = ((ModuleNameId)((ComboBox)sender).SelectedItem).id;
        }

        private void module6_SelectedIndexChanged(object sender, EventArgs e)
        {
            moduleId[6] = ((ModuleNameId)((ComboBox)sender).SelectedItem).id;
        }

        private void module7_SelectedIndexChanged(object sender, EventArgs e)
        {
            moduleId[7] = ((ModuleNameId)((ComboBox)sender).SelectedItem).id;
        }

        private void module8_SelectedIndexChanged(object sender, EventArgs e)
        {
            moduleId[8] = ((ModuleNameId)((ComboBox)sender).SelectedItem).id;
        }

        private void module9_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            moduleId[9] = ((ModuleNameId)((ComboBox)sender).SelectedItem).id;
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
        public int team { get; set; }
        private void button1_Click(object sender, EventArgs e)
        {
            button2.Enabled = false;
            button3.Enabled = false;
            team = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button3.Enabled = false;
            team = 1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button2.Enabled = false;
            team = 2;
        }

        private void label37_Click(object sender, EventArgs e)
        {

        }
    }
}
