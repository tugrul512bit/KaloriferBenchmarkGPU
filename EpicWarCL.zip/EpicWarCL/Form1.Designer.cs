﻿namespace EpicWarCL
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ınfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openCLBasedDDSpaceBattleSimulatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.writtenByTugrulToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.emailHuseyintugrulbuyukisikgmailcomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.huseyintugrulbuyukisikgmailcomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rulesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allShipsStartWith4d8HitpointsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eachShipHasİtsOwnRandomHitPointsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shipSizeİsAnİndicatorOfİnitialShipHitpointsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eachProjectileDeals1d4DamageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shipArmorHas1DamageReductionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allShipsStartWith1d8ShieldPointsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eachShipRegenerates1ShieldPointsAfter1d4TurnssimulationStepsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.performanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eachOpenCLKernelUses64ThreadsPerLocalWorkGroupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usesSingleCommandToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gBMemoryİsMoreThanEnoughToRunThisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doesNotUseCPUToComputeAnythingExceptThisWindowsFpsİndicatorsAndSimilarThingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usesOnlySingleGPUThatUserPicksToStartSimulationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.r7240320CoresCanAchieve40FPSFor64kShipsİnFieldToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.supportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.needsOpenCL12DevicesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.needsDotNetFramework40ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.needs64bitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.module9 = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.label27 = new System.Windows.Forms.Label();
            this.module2 = new System.Windows.Forms.ComboBox();
            this.module1 = new System.Windows.Forms.ComboBox();
            this.module7 = new System.Windows.Forms.ComboBox();
            this.module5 = new System.Windows.Forms.ComboBox();
            this.module3 = new System.Windows.Forms.ComboBox();
            this.module8 = new System.Windows.Forms.ComboBox();
            this.module6 = new System.Windows.Forms.ComboBox();
            this.module4 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.module0 = new System.Windows.Forms.ComboBox();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label35 = new System.Windows.Forms.Label();
            this.hScrollBar1 = new System.Windows.Forms.HScrollBar();
            this.label36 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label37 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(48, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 29);
            this.label1.TabIndex = 1;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1362, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ınfoToolStripMenuItem,
            this.rulesToolStripMenuItem,
            this.performanceToolStripMenuItem,
            this.supportToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // ınfoToolStripMenuItem
            // 
            this.ınfoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openCLBasedDDSpaceBattleSimulatorToolStripMenuItem,
            this.writtenByTugrulToolStripMenuItem,
            this.emailHuseyintugrulbuyukisikgmailcomToolStripMenuItem,
            this.huseyintugrulbuyukisikgmailcomToolStripMenuItem});
            this.ınfoToolStripMenuItem.Name = "ınfoToolStripMenuItem";
            this.ınfoToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.ınfoToolStripMenuItem.Text = "Info";
            // 
            // openCLBasedDDSpaceBattleSimulatorToolStripMenuItem
            // 
            this.openCLBasedDDSpaceBattleSimulatorToolStripMenuItem.Name = "openCLBasedDDSpaceBattleSimulatorToolStripMenuItem";
            this.openCLBasedDDSpaceBattleSimulatorToolStripMenuItem.Size = new System.Drawing.Size(476, 22);
            this.openCLBasedDDSpaceBattleSimulatorToolStripMenuItem.Text = "OpenCL based Dungeons-and-Dragons (in real-time) space battle simulator.";
            // 
            // writtenByTugrulToolStripMenuItem
            // 
            this.writtenByTugrulToolStripMenuItem.Name = "writtenByTugrulToolStripMenuItem";
            this.writtenByTugrulToolStripMenuItem.Size = new System.Drawing.Size(476, 22);
            this.writtenByTugrulToolStripMenuItem.Text = "Uses cekirdekler-api which eases OpenCL usage in C# projects.";
            // 
            // emailHuseyintugrulbuyukisikgmailcomToolStripMenuItem
            // 
            this.emailHuseyintugrulbuyukisikgmailcomToolStripMenuItem.Name = "emailHuseyintugrulbuyukisikgmailcomToolStripMenuItem";
            this.emailHuseyintugrulbuyukisikgmailcomToolStripMenuItem.Size = new System.Drawing.Size(476, 22);
            this.emailHuseyintugrulbuyukisikgmailcomToolStripMenuItem.Text = "Written by Tugrul_512bit.";
            this.emailHuseyintugrulbuyukisikgmailcomToolStripMenuItem.Click += new System.EventHandler(this.emailHuseyintugrulbuyukisikgmailcomToolStripMenuItem_Click);
            // 
            // huseyintugrulbuyukisikgmailcomToolStripMenuItem
            // 
            this.huseyintugrulbuyukisikgmailcomToolStripMenuItem.Name = "huseyintugrulbuyukisikgmailcomToolStripMenuItem";
            this.huseyintugrulbuyukisikgmailcomToolStripMenuItem.Size = new System.Drawing.Size(476, 22);
            this.huseyintugrulbuyukisikgmailcomToolStripMenuItem.Text = "E-mail: huseyin.tugrul.buyukisik@gmail.com";
            this.huseyintugrulbuyukisikgmailcomToolStripMenuItem.Click += new System.EventHandler(this.emailHuseyintugrulbuyukisikgmailcomToolStripMenuItem_Click);
            // 
            // rulesToolStripMenuItem
            // 
            this.rulesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.allShipsStartWith4d8HitpointsToolStripMenuItem,
            this.eachProjectileDeals1d4DamageToolStripMenuItem,
            this.shipArmorHas1DamageReductionToolStripMenuItem,
            this.allShipsStartWith1d8ShieldPointsToolStripMenuItem});
            this.rulesToolStripMenuItem.Name = "rulesToolStripMenuItem";
            this.rulesToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.rulesToolStripMenuItem.Text = "Rules";
            // 
            // allShipsStartWith4d8HitpointsToolStripMenuItem
            // 
            this.allShipsStartWith4d8HitpointsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eachShipHasİtsOwnRandomHitPointsToolStripMenuItem,
            this.shipSizeİsAnİndicatorOfİnitialShipHitpointsToolStripMenuItem});
            this.allShipsStartWith4d8HitpointsToolStripMenuItem.Name = "allShipsStartWith4d8HitpointsToolStripMenuItem";
            this.allShipsStartWith4d8HitpointsToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.allShipsStartWith4d8HitpointsToolStripMenuItem.Text = "All ships start with 5d10 hitpoints.";
            // 
            // eachShipHasİtsOwnRandomHitPointsToolStripMenuItem
            // 
            this.eachShipHasİtsOwnRandomHitPointsToolStripMenuItem.Name = "eachShipHasİtsOwnRandomHitPointsToolStripMenuItem";
            this.eachShipHasİtsOwnRandomHitPointsToolStripMenuItem.Size = new System.Drawing.Size(317, 22);
            this.eachShipHasİtsOwnRandomHitPointsToolStripMenuItem.Text = "Each ship has its own random hitpoints.";
            // 
            // shipSizeİsAnİndicatorOfİnitialShipHitpointsToolStripMenuItem
            // 
            this.shipSizeİsAnİndicatorOfİnitialShipHitpointsToolStripMenuItem.Name = "shipSizeİsAnİndicatorOfİnitialShipHitpointsToolStripMenuItem";
            this.shipSizeİsAnİndicatorOfİnitialShipHitpointsToolStripMenuItem.Size = new System.Drawing.Size(317, 22);
            this.shipSizeİsAnİndicatorOfİnitialShipHitpointsToolStripMenuItem.Text = "Ship size is an indicator of initial ship hitpoints";
            // 
            // eachProjectileDeals1d4DamageToolStripMenuItem
            // 
            this.eachProjectileDeals1d4DamageToolStripMenuItem.Name = "eachProjectileDeals1d4DamageToolStripMenuItem";
            this.eachProjectileDeals1d4DamageToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.eachProjectileDeals1d4DamageToolStripMenuItem.Text = "Each projectile deals 1d4 damage.";
            // 
            // shipArmorHas1DamageReductionToolStripMenuItem
            // 
            this.shipArmorHas1DamageReductionToolStripMenuItem.Name = "shipArmorHas1DamageReductionToolStripMenuItem";
            this.shipArmorHas1DamageReductionToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.shipArmorHas1DamageReductionToolStripMenuItem.Text = "Ship armor has 1 damage reduction.";
            // 
            // allShipsStartWith1d8ShieldPointsToolStripMenuItem
            // 
            this.allShipsStartWith1d8ShieldPointsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eachShipRegenerates1ShieldPointsAfter1d4TurnssimulationStepsToolStripMenuItem});
            this.allShipsStartWith1d8ShieldPointsToolStripMenuItem.Name = "allShipsStartWith1d8ShieldPointsToolStripMenuItem";
            this.allShipsStartWith1d8ShieldPointsToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.allShipsStartWith1d8ShieldPointsToolStripMenuItem.Text = "All ships start with 8 shield points.";
            this.allShipsStartWith1d8ShieldPointsToolStripMenuItem.Click += new System.EventHandler(this.allShipsStartWith1d8ShieldPointsToolStripMenuItem_Click);
            // 
            // eachShipRegenerates1ShieldPointsAfter1d4TurnssimulationStepsToolStripMenuItem
            // 
            this.eachShipRegenerates1ShieldPointsAfter1d4TurnssimulationStepsToolStripMenuItem.Name = "eachShipRegenerates1ShieldPointsAfter1d4TurnssimulationStepsToolStripMenuItem";
            this.eachShipRegenerates1ShieldPointsAfter1d4TurnssimulationStepsToolStripMenuItem.Size = new System.Drawing.Size(442, 22);
            this.eachShipRegenerates1ShieldPointsAfter1d4TurnssimulationStepsToolStripMenuItem.Text = "Each ship regenerates 1 shield points after 100  turns(simulation steps)";
            // 
            // performanceToolStripMenuItem
            // 
            this.performanceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eachOpenCLKernelUses64ThreadsPerLocalWorkGroupToolStripMenuItem,
            this.usesSingleCommandToolStripMenuItem,
            this.gBMemoryİsMoreThanEnoughToRunThisToolStripMenuItem,
            this.doesNotUseCPUToComputeAnythingExceptThisWindowsFpsİndicatorsAndSimilarThingsToolStripMenuItem,
            this.usesOnlySingleGPUThatUserPicksToStartSimulationToolStripMenuItem,
            this.r7240320CoresCanAchieve40FPSFor64kShipsİnFieldToolStripMenuItem});
            this.performanceToolStripMenuItem.Name = "performanceToolStripMenuItem";
            this.performanceToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.performanceToolStripMenuItem.Text = "Performance";
            // 
            // eachOpenCLKernelUses64ThreadsPerLocalWorkGroupToolStripMenuItem
            // 
            this.eachOpenCLKernelUses64ThreadsPerLocalWorkGroupToolStripMenuItem.Name = "eachOpenCLKernelUses64ThreadsPerLocalWorkGroupToolStripMenuItem";
            this.eachOpenCLKernelUses64ThreadsPerLocalWorkGroupToolStripMenuItem.Size = new System.Drawing.Size(569, 22);
            this.eachOpenCLKernelUses64ThreadsPerLocalWorkGroupToolStripMenuItem.Text = "Each OpenCL kernel uses 64 threads per local work group.";
            // 
            // usesSingleCommandToolStripMenuItem
            // 
            this.usesSingleCommandToolStripMenuItem.Name = "usesSingleCommandToolStripMenuItem";
            this.usesSingleCommandToolStripMenuItem.Size = new System.Drawing.Size(569, 22);
            this.usesSingleCommandToolStripMenuItem.Text = "Uses single command queue to process all commands.";
            // 
            // gBMemoryİsMoreThanEnoughToRunThisToolStripMenuItem
            // 
            this.gBMemoryİsMoreThanEnoughToRunThisToolStripMenuItem.Name = "gBMemoryİsMoreThanEnoughToRunThisToolStripMenuItem";
            this.gBMemoryİsMoreThanEnoughToRunThisToolStripMenuItem.Size = new System.Drawing.Size(569, 22);
            this.gBMemoryİsMoreThanEnoughToRunThisToolStripMenuItem.Text = "2GB memory is more than enough to run this.";
            // 
            // doesNotUseCPUToComputeAnythingExceptThisWindowsFpsİndicatorsAndSimilarThingsToolStripMenuItem
            // 
            this.doesNotUseCPUToComputeAnythingExceptThisWindowsFpsİndicatorsAndSimilarThingsToolStripMenuItem.Name = "doesNotUseCPUToComputeAnythingExceptThisWindowsFpsİndicatorsAndSimilarThingsToolS" +
    "tripMenuItem";
            this.doesNotUseCPUToComputeAnythingExceptThisWindowsFpsİndicatorsAndSimilarThingsToolStripMenuItem.Size = new System.Drawing.Size(569, 22);
            this.doesNotUseCPUToComputeAnythingExceptThisWindowsFpsİndicatorsAndSimilarThingsToolStripMenuItem.Text = "Does not use CPU to compute anything except this window\'s fps indicators and simi" +
    "lar things.";
            // 
            // usesOnlySingleGPUThatUserPicksToStartSimulationToolStripMenuItem
            // 
            this.usesOnlySingleGPUThatUserPicksToStartSimulationToolStripMenuItem.Name = "usesOnlySingleGPUThatUserPicksToStartSimulationToolStripMenuItem";
            this.usesOnlySingleGPUThatUserPicksToStartSimulationToolStripMenuItem.Size = new System.Drawing.Size(569, 22);
            this.usesOnlySingleGPUThatUserPicksToStartSimulationToolStripMenuItem.Text = "Uses only single GPU that user picks to start simulation.";
            // 
            // r7240320CoresCanAchieve40FPSFor64kShipsİnFieldToolStripMenuItem
            // 
            this.r7240320CoresCanAchieve40FPSFor64kShipsİnFieldToolStripMenuItem.Name = "r7240320CoresCanAchieve40FPSFor64kShipsİnFieldToolStripMenuItem";
            this.r7240320CoresCanAchieve40FPSFor64kShipsİnFieldToolStripMenuItem.Size = new System.Drawing.Size(569, 22);
            this.r7240320CoresCanAchieve40FPSFor64kShipsİnFieldToolStripMenuItem.Text = "R7-240(320 cores) can achieve 40 FPS for 64k ships in field.";
            // 
            // supportToolStripMenuItem
            // 
            this.supportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.needsOpenCL12DevicesToolStripMenuItem,
            this.needsDotNetFramework40ToolStripMenuItem,
            this.needs64bitToolStripMenuItem});
            this.supportToolStripMenuItem.Name = "supportToolStripMenuItem";
            this.supportToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.supportToolStripMenuItem.Text = "Support";
            // 
            // needsOpenCL12DevicesToolStripMenuItem
            // 
            this.needsOpenCL12DevicesToolStripMenuItem.Name = "needsOpenCL12DevicesToolStripMenuItem";
            this.needsOpenCL12DevicesToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.needsOpenCL12DevicesToolStripMenuItem.Text = "Needs OpenCL 1.2 Devices";
            // 
            // needsDotNetFramework40ToolStripMenuItem
            // 
            this.needsDotNetFramework40ToolStripMenuItem.Name = "needsDotNetFramework40ToolStripMenuItem";
            this.needsDotNetFramework40ToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.needsDotNetFramework40ToolStripMenuItem.Text = "Needs Dot-Net-Framework-4.0+";
            // 
            // needs64bitToolStripMenuItem
            // 
            this.needs64bitToolStripMenuItem.Name = "needs64bitToolStripMenuItem";
            this.needs64bitToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.needs64bitToolStripMenuItem.Text = "Needs 64-bit";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Increment = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.numericUpDown1.Location = new System.Drawing.Point(555, 4);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            4096,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1024,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown1.TabIndex = 3;
            this.numericUpDown1.Value = new decimal(new int[] {
            1024,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(344, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(207, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Render Resolution";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(692, -1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "x";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Increment = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.numericUpDown2.Location = new System.Drawing.Point(737, 4);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            4096,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            768,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown2.TabIndex = 6;
            this.numericUpDown2.Value = new decimal(new int[] {
            768,
            0,
            0,
            0});
            this.numericUpDown2.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(44, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(314, 327);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.module9);
            this.panel1.Controls.Add(this.label32);
            this.panel1.Controls.Add(this.label31);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Controls.Add(this.numericUpDown7);
            this.panel1.Controls.Add(this.numericUpDown6);
            this.panel1.Controls.Add(this.numericUpDown5);
            this.panel1.Controls.Add(this.numericUpDown4);
            this.panel1.Controls.Add(this.numericUpDown3);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.module2);
            this.panel1.Controls.Add(this.module1);
            this.panel1.Controls.Add(this.module7);
            this.panel1.Controls.Add(this.module5);
            this.panel1.Controls.Add(this.module3);
            this.panel1.Controls.Add(this.module8);
            this.panel1.Controls.Add(this.module6);
            this.panel1.Controls.Add(this.module4);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.module0);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(347, 40);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(459, 383);
            this.panel1.TabIndex = 8;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.ForeColor = System.Drawing.Color.Blue;
            this.button3.Location = new System.Drawing.Point(381, 92);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 33;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.Color.Green;
            this.button2.Location = new System.Drawing.Point(381, 59);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 32;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(381, 23);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 31;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // module9
            // 
            this.module9.FormattingEnabled = true;
            this.module9.Items.AddRange(new object[] {
            "Power Source",
            "Energy Capacitor",
            "Shield Generator",
            "Cannon Turret"});
            this.module9.Location = new System.Drawing.Point(124, 256);
            this.module9.Name = "module9";
            this.module9.Size = new System.Drawing.Size(121, 21);
            this.module9.TabIndex = 30;
            this.module9.SelectedIndexChanged += new System.EventHandler(this.module9_SelectedIndexChanged);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(290, 337);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(81, 13);
            this.label32.TabIndex = 29;
            this.label32.Text = "Gunnery Officer";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(291, 314);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(39, 13);
            this.label31.TabIndex = 28;
            this.label31.Text = "Marine";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(177, 335);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(60, 13);
            this.label30.TabIndex = 27;
            this.label30.Text = "Technician";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(122, 335);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(49, 13);
            this.label29.TabIndex = 26;
            this.label29.Text = "Engineer";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(65, 335);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(43, 13);
            this.label28.TabIndex = 25;
            this.label28.Text = "Captain";
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.Location = new System.Drawing.Point(243, 331);
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(41, 20);
            this.numericUpDown7.TabIndex = 24;
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.Location = new System.Drawing.Point(243, 309);
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(41, 20);
            this.numericUpDown6.TabIndex = 23;
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.Location = new System.Drawing.Point(181, 310);
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(41, 20);
            this.numericUpDown5.TabIndex = 22;
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Location = new System.Drawing.Point(124, 310);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(41, 20);
            this.numericUpDown4.TabIndex = 21;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(71, 310);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(41, 20);
            this.numericUpDown3.TabIndex = 20;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label27.Location = new System.Drawing.Point(137, 279);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(244, 25);
            this.label27.TabIndex = 19;
            this.label27.Text = "Crew(Not working yet)";
            // 
            // module2
            // 
            this.module2.FormattingEnabled = true;
            this.module2.Items.AddRange(new object[] {
            "Power Source",
            "Energy Capacitor",
            "Shield Generator",
            "Cannon Turret"});
            this.module2.Location = new System.Drawing.Point(198, 115);
            this.module2.Name = "module2";
            this.module2.Size = new System.Drawing.Size(121, 21);
            this.module2.TabIndex = 18;
            this.module2.SelectedIndexChanged += new System.EventHandler(this.module2_SelectedIndexChanged);
            // 
            // module1
            // 
            this.module1.FormattingEnabled = true;
            this.module1.Items.AddRange(new object[] {
            "Power Source",
            "Energy Capacitor",
            "Shield Generator",
            "Cannon Turret"});
            this.module1.Location = new System.Drawing.Point(44, 114);
            this.module1.Name = "module1";
            this.module1.Size = new System.Drawing.Size(121, 21);
            this.module1.TabIndex = 17;
            this.module1.SelectedIndexChanged += new System.EventHandler(this.comboBox8_SelectedIndexChanged);
            // 
            // module7
            // 
            this.module7.FormattingEnabled = true;
            this.module7.Items.AddRange(new object[] {
            "Power Source",
            "Energy Capacitor",
            "Shield Generator",
            "Cannon Turret"});
            this.module7.Location = new System.Drawing.Point(16, 229);
            this.module7.Name = "module7";
            this.module7.Size = new System.Drawing.Size(121, 21);
            this.module7.TabIndex = 16;
            this.module7.SelectedIndexChanged += new System.EventHandler(this.module7_SelectedIndexChanged);
            // 
            // module5
            // 
            this.module5.FormattingEnabled = true;
            this.module5.Items.AddRange(new object[] {
            "Power Source",
            "Energy Capacitor",
            "Shield Generator",
            "Cannon Turret"});
            this.module5.Location = new System.Drawing.Point(16, 192);
            this.module5.Name = "module5";
            this.module5.Size = new System.Drawing.Size(121, 21);
            this.module5.TabIndex = 15;
            this.module5.SelectedIndexChanged += new System.EventHandler(this.module5_SelectedIndexChanged);
            // 
            // module3
            // 
            this.module3.FormattingEnabled = true;
            this.module3.Items.AddRange(new object[] {
            "Power Source",
            "Energy Capacitor",
            "Shield Generator",
            "Cannon Turret"});
            this.module3.Location = new System.Drawing.Point(16, 154);
            this.module3.Name = "module3";
            this.module3.Size = new System.Drawing.Size(121, 21);
            this.module3.TabIndex = 14;
            this.module3.SelectedIndexChanged += new System.EventHandler(this.module3_SelectedIndexChanged);
            // 
            // module8
            // 
            this.module8.FormattingEnabled = true;
            this.module8.Items.AddRange(new object[] {
            "Power Source",
            "Energy Capacitor",
            "Shield Generator",
            "Cannon Turret"});
            this.module8.Location = new System.Drawing.Point(224, 229);
            this.module8.Name = "module8";
            this.module8.Size = new System.Drawing.Size(121, 21);
            this.module8.TabIndex = 13;
            this.module8.SelectedIndexChanged += new System.EventHandler(this.module8_SelectedIndexChanged);
            // 
            // module6
            // 
            this.module6.FormattingEnabled = true;
            this.module6.Items.AddRange(new object[] {
            "Power Source",
            "Energy Capacitor",
            "Shield Generator",
            "Cannon Turret"});
            this.module6.Location = new System.Drawing.Point(224, 192);
            this.module6.Name = "module6";
            this.module6.Size = new System.Drawing.Size(121, 21);
            this.module6.TabIndex = 12;
            this.module6.SelectedIndexChanged += new System.EventHandler(this.module6_SelectedIndexChanged);
            // 
            // module4
            // 
            this.module4.FormattingEnabled = true;
            this.module4.Items.AddRange(new object[] {
            "Power Source",
            "Energy Capacitor",
            "Shield Generator",
            "Cannon Turret"});
            this.module4.Location = new System.Drawing.Point(224, 154);
            this.module4.Name = "module4";
            this.module4.Size = new System.Drawing.Size(121, 21);
            this.module4.TabIndex = 11;
            this.module4.SelectedIndexChanged += new System.EventHandler(this.module4_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(39, 4);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(233, 25);
            this.label11.TabIndex = 10;
            this.label11.Text = "Customize Your Ship";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // module0
            // 
            this.module0.FormattingEnabled = true;
            this.module0.Items.AddRange(new object[] {
            "Power Source",
            "Energy Capacitor",
            "Shield Generator",
            "Cannon Turret"});
            this.module0.Location = new System.Drawing.Point(114, 53);
            this.module0.Name = "module0";
            this.module0.Size = new System.Drawing.Size(121, 21);
            this.module0.TabIndex = 8;
            this.module0.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Location = new System.Drawing.Point(866, 238);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(431, 185);
            this.tabControl2.TabIndex = 10;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.label21);
            this.tabPage6.Controls.Add(this.label20);
            this.tabPage6.Controls.Add(this.label19);
            this.tabPage6.Controls.Add(this.label18);
            this.tabPage6.Controls.Add(this.label17);
            this.tabPage6.Controls.Add(this.label16);
            this.tabPage6.Controls.Add(this.label15);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(423, 159);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "Ship Levelup";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(17, 128);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(79, 13);
            this.label21.TabIndex = 11;
            this.label21.Text = "+%3 movement";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(16, 105);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(140, 13);
            this.label20.TabIndex = 10;
            this.label20.Text = "+1 boarding range(base=50)";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(16, 81);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 13);
            this.label19.TabIndex = 9;
            this.label19.Text = "+1 soldier";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(15, 60);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(146, 13);
            this.label18.TabIndex = 8;
            this.label18.Text = "+1 targetting range (base=50)";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(15, 40);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(122, 13);
            this.label17.TabIndex = 7;
            this.label17.Text = "+1 ship radius (base=10)";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(15, 23);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(117, 13);
            this.label16.TabIndex = 6;
            this.label16.Text = "+1 energy per time step";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(15, 6);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(76, 13);
            this.label15.TabIndex = 5;
            this.label15.Text = "+1d8 hit points";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.label26);
            this.tabPage7.Controls.Add(this.label25);
            this.tabPage7.Controls.Add(this.label24);
            this.tabPage7.Controls.Add(this.label23);
            this.tabPage7.Controls.Add(this.label22);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(423, 159);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "Crew";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(20, 108);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(270, 13);
            this.label26.TabIndex = 10;
            this.label26.Text = "Captain: controls ship, regains control if first captain dies";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(20, 83);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(393, 13);
            this.label25.TabIndex = 9;
            this.label25.Text = "Gunnery officer: -1 turret targetting error(base=10 degrees), +1 boarding resista" +
    "nce";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(20, 61);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(279, 13);
            this.label24.TabIndex = 8;
            this.label24.Text = "Soldier: +1 boarding resistance, +1 boarding attack power";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(20, 39);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(319, 13);
            this.label23.TabIndex = 7;
            this.label23.Text = "Technician: repair 1 hp per 30 time steps, -2 shield regen time step";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(20, 15);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(338, 13);
            this.label22.TabIndex = 6;
            this.label22.Text = "Engineer: +1 hp per levelup(retroactive), repair 1 hp per 100 time steps";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.label34);
            this.tabPage8.Controls.Add(this.label33);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(423, 159);
            this.tabPage8.TabIndex = 2;
            this.tabPage8.Text = "Captain Level Up";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(31, 47);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(344, 13);
            this.label34.TabIndex = 8;
            this.label34.Text = "Other: +1 target prediction (to fire future positions of target) for 1 cannon";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(31, 18);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(376, 13);
            this.label33.TabIndex = 7;
            this.label33.Text = "First captain: +1 evasive maneuver(base=0). Each point = 1d20 evasion on 20";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.label12);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(427, 163);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Cannon Turret";
            this.tabPage4.UseVisualStyleBackColor = true;
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(35, 86);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(189, 13);
            this.label14.TabIndex = 5;
            this.label14.Text = "-2 energy per time step when reloading";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(35, 58);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(119, 13);
            this.label13.TabIndex = 4;
            this.label13.Text = "10 time steps per reload";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(35, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(307, 13);
            this.label12.TabIndex = 3;
            this.label12.Text = "1d4 damage per shell (magnetically accelerated, high explosive)";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(427, 163);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Shield Generator";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(35, 117);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(213, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "-1 energy unit per time step for each hitpoint";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(35, 86);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(225, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "-1 energy unit per time step when regenerating";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(35, 56);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(170, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "+1 regeneration per 100 time steps";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(35, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "8 hitpoints";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(427, 163);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Energy Capacitor";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "100 energy unit storage";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(427, 163);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Power Source";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 51);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "1 energy unit storage";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "+1 energy units per time step";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(862, 40);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(435, 189);
            this.tabControl1.TabIndex = 9;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(48, 51);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(127, 17);
            this.checkBox1.TabIndex = 11;
            this.checkBox1.Text = "Detailed Console Log";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label35.Location = new System.Drawing.Point(451, 431);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(253, 25);
            this.label35.TabIndex = 13;
            this.label35.Text = "Number Of Spaceships";
            this.label35.Click += new System.EventHandler(this.label35_Click);
            // 
            // hScrollBar1
            // 
            this.hScrollBar1.LargeChange = 3;
            this.hScrollBar1.Location = new System.Drawing.Point(418, 458);
            this.hScrollBar1.Maximum = 24;
            this.hScrollBar1.Minimum = 10;
            this.hScrollBar1.Name = "hScrollBar1";
            this.hScrollBar1.Size = new System.Drawing.Size(330, 27);
            this.hScrollBar1.TabIndex = 14;
            this.hScrollBar1.Value = 17;
            this.hScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar1_Scroll);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label36.Location = new System.Drawing.Point(456, 485);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(90, 25);
            this.label36.TabIndex = 15;
            this.label36.Text = "131072";
            this.label36.Click += new System.EventHandler(this.label36_Click);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(48, 27);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(216, 17);
            this.checkBox2.TabIndex = 16;
            this.checkBox2.Text = "Simulations Per Second Limiter (30 SPS)";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label37.Location = new System.Drawing.Point(706, 35);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(122, 25);
            this.label37.TabIndex = 34;
            this.label37.Text = "Pick Team";
            this.label37.Click += new System.EventHandler(this.label37_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1362, 615);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.hScrollBar1);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Epic War CL v0.01";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown_1);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ınfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rulesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openCLBasedDDSpaceBattleSimulatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem writtenByTugrulToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem emailHuseyintugrulbuyukisikgmailcomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem huseyintugrulbuyukisikgmailcomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allShipsStartWith4d8HitpointsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eachShipHasİtsOwnRandomHitPointsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shipSizeİsAnİndicatorOfİnitialShipHitpointsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eachProjectileDeals1d4DamageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shipArmorHas1DamageReductionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allShipsStartWith1d8ShieldPointsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eachShipRegenerates1ShieldPointsAfter1d4TurnssimulationStepsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem performanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eachOpenCLKernelUses64ThreadsPerLocalWorkGroupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usesSingleCommandToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gBMemoryİsMoreThanEnoughToRunThisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doesNotUseCPUToComputeAnythingExceptThisWindowsFpsİndicatorsAndSimilarThingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usesOnlySingleGPUThatUserPicksToStartSimulationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem r7240320CoresCanAchieve40FPSFor64kShipsİnFieldToolStripMenuItem;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox module0;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox module4;
        private System.Windows.Forms.ComboBox module7;
        private System.Windows.Forms.ComboBox module5;
        private System.Windows.Forms.ComboBox module3;
        private System.Windows.Forms.ComboBox module8;
        private System.Windows.Forms.ComboBox module6;
        private System.Windows.Forms.ComboBox module2;
        private System.Windows.Forms.ComboBox module1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.HScrollBar hScrollBar1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.ToolStripMenuItem supportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem needsOpenCL12DevicesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem needsDotNetFramework40ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem needs64bitToolStripMenuItem;
        private System.Windows.Forms.ComboBox module9;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label37;
    }
}

